# Firelink Chronicle

An English personal blog for DiamondhunterSA, inspired by the atmosphere of Dark Souls and Elden Ring.

Live: https://diamondhuntersa.github.io/

## Structure

| Name | Purpose | URL |
| --- | --- | --- |
| Firelink | Home, featured entries, latest entries | `/` |
| The Wanderer | About and public links | `/about/` |
| The Forge | Projects | `/projects/` |
| The Archives | Learning notes | `/notes/` |
| Beyond the Fog | Explorations | `/explorations/` |
| The Chronicle | All entries, with pagination as the collection grows | `/posts/` |
| The Timeline | Archive by year and date | `/archives/` |
| Threads of the journey | Tag index and tag pages | `/tags/` |
| Seek a spark | Full-text search with section filters | `/search/` |

RSS is at `/feed.xml`. GitHub Pages serves `/404.html` for missing pages.

## Write and publish

Use Node.js 20 or newer. Install dependencies once:

```sh
npm install
```

1. Edit `site.config.json` to update the name, introduction, public GitHub link, and interests.
2. Add or edit a Markdown file in `_content/`.
3. Build, validate, and optionally preview:

```sh
npm run build
npm run check
npm run serve
```

The preview is at http://127.0.0.1:4173. To prepare the flat, directly addressable deployment used by this site, run `npm run export`. Publish the contents of `.preview/publish/` to the repository root. GitHub Pages publishes the committed HTML from `main` → `/ (root)`. The deployed repository also includes `firelink-source.zip` with the editable source.

Front matter uses one value per line. Use double-quoted JSON arrays for tags:

```yaml
---
title: A descriptive entry title
slug: a-descriptive-entry-title
section: notes
date: 2026-10-07
description: A short summary for lists, search, and RSS.
tags: ["Learning", "Writing"]
featured: false
cover: ashen-world.webp
starter: false
draft: false
---

## Your first heading

Write your entry here.
```

`section` must be `projects`, `notes`, or `explorations`. `slug` must be unique and use lowercase letters, numbers, and hyphens. Keep it stable when changing the title. `updated` is an optional date; `status` is an optional project status. Dates use `YYYY-MM-DD`. Optional booleans are `featured`, `starter`, and `draft`.

Draft entries are excluded from generated pages, search, RSS, and the sitemap. Source files remain visible in this public GitHub repository. The supplied learning and exploration entries are explicitly labeled starter content; replace or remove them as you add your own writing.

The build owns only the files listed in `_tools/generated.json`. Stale generated entry and tag pages are removed on the next build. Do not edit generated HTML directly; edit Markdown, `site.config.json`, `_tools/build.mjs`, or `assets/` instead.

## Features

- Static, directly addressable pages; navigation works without JavaScript.
- Client-side full-text search, highlighted results, filters, empty and error states.
- Responsive navigation, keyboard search shortcut (`/`), and visible focus styles.
- Heading links, reading progress, table of contents, code copying, and share-link copying.
- Related and adjacent entries; categories, tags, archive, RSS, sitemap, and custom 404.
- Locally hosted compressed WebP imagery; no analytics or external scripts.
- Reduced-motion and print styles.

## Image sources

Game imagery is sourced from official Bandai Namco promotional media and belongs to the respective rights holders:

- [Elden Ring media gallery](https://en.bandainamcoent.eu/elden-ring/elden-ring/media): `ELDENRING_17_4K.jpg`, `ELDENRING_02_4K.jpg`, and `elden-ring-newscreen01.png`.
- [Dark Souls III media gallery](https://en.bandainamcoent.eu/dark-souls/dark-souls-iii/media): `In game (10).jpg`.

This is a personal fan-inspired blog. It does not represent FromSoftware or Bandai Namco. Attribution is also present on the About page.
