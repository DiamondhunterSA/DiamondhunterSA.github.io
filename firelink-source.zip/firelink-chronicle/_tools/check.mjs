import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const files=JSON.parse(fs.readFileSync(path.join(root,'_tools/generated.json'),'utf8'));
const errors=[];
for(const file of files.filter(f=>f.endsWith('.html'))){
  const html=fs.readFileSync(path.join(root,file),'utf8');
  if(!html.includes('<html lang="en">'))errors.push(`${file}: missing English language`);
  if(/[\u4e00-\u9fff]/.test(html))errors.push(`${file}: contains Chinese text`);
  const ids=[...html.matchAll(/\bid="([^"]+)"/g)].map(m=>m[1]);
  if(new Set(ids).size!==ids.length)errors.push(`${file}: duplicate element IDs`);
  const current='/' + file.replace(/index\.html$/,'');
  for(const match of html.matchAll(/\b(?:href|src)="([^"]+)"/g)){
    const raw=match[1];if(/^(https?:|data:|mailto:)/.test(raw))continue;
    const url=new URL(raw,'http://local'+current);
    let target=path.join(root,decodeURIComponent(url.pathname));
    if(url.pathname.endsWith('/'))target=path.join(target,'index.html');
    if(!fs.existsSync(target)){errors.push(`${file}: missing ${raw}`);continue;}
    if(url.hash&&path.extname(target)==='.html'){
      const targetHtml=fs.readFileSync(target,'utf8');
      const id=decodeURIComponent(url.hash.slice(1));
      if(!targetHtml.includes(`id="${id}"`))errors.push(`${file}: missing anchor ${raw}`);
    }
  }
}
const index=JSON.parse(fs.readFileSync(path.join(root,'assets/search-index.json'),'utf8'));
for(const post of index){if(!post.text||!post.title||!post.tags.length)errors.push(`Incomplete search record: ${post.url}`);}
if(errors.length){console.error(errors.join('\n'));process.exitCode=1;}else{console.log(`Passed: ${files.filter(f=>f.endsWith('.html')).length} pages, internal links, anchors, English text, and ${index.length} full-text search entries.`);}
