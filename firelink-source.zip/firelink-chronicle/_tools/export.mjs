import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const output=process.env.FIRELINK_OUTPUT ? path.resolve(process.env.FIRELINK_OUTPUT) : path.join(root,'.preview','publish');
const files=JSON.parse(fs.readFileSync(path.join(root,'_tools/generated.json'),'utf8'));
const routeMap=new Map(files.filter(f=>f.endsWith('/index.html')).map(file=>{
  const route='/'+file.replace(/index\.html$/,'');
  const prefix=route.startsWith('/posts/')&&route!=='/posts/'?'entry-':route.startsWith('/tags/')&&route!=='/tags/'?'tag-':'';
  const name=prefix ? prefix+route.split('/').filter(Boolean).slice(1).join('-')+'.html' : route.slice(1,-1).replaceAll('/','-')+'.html';
  return [route,'/'+name];
}));
const replacements=[...routeMap].sort((a,b)=>b[0].length-a[0].length);
function rewrite(text){for(const [old,url] of replacements)text=text.split(old).join(url);return text.replaceAll('/assets/','/');}
fs.mkdirSync(output,{recursive:true});
const published=[];
function copy(name,bytes){const target=path.join(output,name);if(!target.startsWith(output+path.sep))throw new Error('Unsafe export target');fs.writeFileSync(target,bytes);published.push(name);}
for(const file of files){const name=file==='index.html'?'index.html':file.endsWith('/index.html')?routeMap.get('/'+file.replace(/index\.html$/,'')).slice(1):path.basename(file);copy(name,rewrite(fs.readFileSync(path.join(root,file),'utf8')));}
for(const file of fs.readdirSync(path.join(root,'assets')).filter(f=>/\.(?:webp|css|js|svg)$/.test(f))){const source=path.join(root,'assets',file);copy(file,/\.(?:css|js|svg)$/.test(file)?rewrite(fs.readFileSync(source,'utf8')):fs.readFileSync(source));}
copy('.nojekyll','');
copy('README.md',`# Firelink Chronicle\n\nAn English, Souls-inspired journal by DiamondhunterSA.\n\nLive: https://diamondhuntersa.github.io/\n\n## Main paths\n\n- Firelink — Home\n- The Wanderer — [About](https://diamondhuntersa.github.io/about.html)\n- The Forge — [Projects](https://diamondhuntersa.github.io/projects.html)\n- The Archives — [Learning Notes](https://diamondhuntersa.github.io/notes.html)\n- Beyond the Fog — [Explorations](https://diamondhuntersa.github.io/explorations.html)\n\nAlso includes all entries, tags, categories, a timeline, full-text search, RSS, and a custom 404.\n\n## Source and writing\n\nThe editable Markdown, configuration, build tools, and source assets are included in [firelink-source.zip](firelink-source.zip). Extract the source, use Node.js 20 or newer, then run:\n\n\x60\x60\x60sh\nnpm install\nnpm run build\nnpm run check\nnpm run serve\nnpm run export\n\x60\x60\x60\n\nThe source README explains how to write entries. The exported files are in \x60.preview/publish/\x60; publish their contents to this repository root. The site uses independent static HTML pages for direct links and refreshes. GitHub Pages publishes from \x60main\x60 → \x60/ (root)\x60.\n\nThe initial learning and exploration entries are explicitly labeled starter content. Replace them as you add your own writing.\n\n## Imagery\n\nImages are compressed promotional screenshots from the official [Elden Ring](https://en.bandainamcoent.eu/elden-ring/elden-ring/media) and [Dark Souls III](https://en.bandainamcoent.eu/dark-souls/dark-souls-iii/media) galleries. Game imagery belongs to the respective rights holders. This personal fan-inspired site does not represent FromSoftware or Bandai Namco.\n`);
const errors=[];
for(const file of published.filter(f=>f.endsWith('.html'))){const html=fs.readFileSync(path.join(output,file),'utf8');for(const m of html.matchAll(/(?:href|src)="([^"#]+)(?:#[^"]*)?"/g)){if(!m[1].startsWith('/'))continue;let dest=m[1].split('#')[0].split('?')[0].slice(1)||'index.html';if(!fs.existsSync(path.join(output,dest)))errors.push(`${file}: missing ${dest}`);}}
if(errors.length)throw new Error(errors.join('\n'));
console.log(`Exported and checked ${published.length} files to ${output}`);
